# Landmark Image Classification Using Pre-trained ResNet50

## Project Type
Individual Mini Project – Pre-trained Deep Learning Models

## Objective
Demonstrate the complete workflow:
Input → Pre-processing → Pre-trained ResNet50 → Inference → Post-processing → Output → Application

This project intentionally does NOT train ResNet50 from scratch and does NOT fine-tune it. It uses the publicly available ResNet50 model with ImageNet pre-trained weights.

## Important Technical Note
The standard ResNet50 ImageNet model predicts 1000 ImageNet categories. It is NOT a dedicated Taj Mahal/Eiffel Tower/India Gate classifier. Therefore, the notebook reports the model's actual ImageNet top-5 predictions rather than inventing landmark-specific accuracy.

If your faculty requires exact landmark names as output, use a landmark-specific pre-trained model and document its source, training dataset, and license.

## Included
- Complete Jupyter/Google Colab notebook
- Streamlit application
- requirements.txt
- README
- sample image input folder
- results folder

## Setup

### Windows / VS Code
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

### Google Colab
Run the installation cell in the notebook.

## Run the notebook
Open:
`notebook/Landmark_Image_Classification_ResNet50.ipynb`

Upload an image when prompted.

## Run the Streamlit app
From the project root:
```bash
streamlit run app/app.py
```

## Suggested test images
Use public-domain or appropriately licensed images of:
- Taj Mahal
- Eiffel Tower
- India Gate
- Colosseum
- Other landmark/architecture images

Place local test images in `images/`.

## Model Information
Model: ResNet50
Weights: ImageNet
Input: 224 × 224 × 3 RGB image
Output: 1000 ImageNet class probabilities

Official Keras documentation:
https://keras.io/api/applications/resnet/

Model implementation/source:
https://github.com/keras-team/keras

For submission, verify and record the current license/terms shown by the official model/source pages and the ImageNet dataset/terms applicable to the weights you use.

## Assignment Coverage
1. Project Title ✓
2. Student Details ✓
3. Problem Statement ✓
4. Objective ✓
5. Introduction to Pre-trained Model ✓
6. Why Model Selected ✓
7. Architecture / Working Principle ✓
8. Libraries and Requirements ✓
9. Installation ✓
10. Imports ✓
11. Model Loading ✓
12. Input Preparation ✓
13. Pre-processing ✓
14. Inference ✓
15. Output Processing ✓
16. Visualization ✓
17. Test Cases ✓
18. Results / Observations ✓
19. Limitations ✓
20. Future Scope ✓
21. Conclusion ✓

## Viva Focus
Be prepared to explain:
- What is a pre-trained model?
- What is inference?
- Training vs inference
- What ResNet50 learned from ImageNet
- Input and output dimensions
- Why preprocessing is required
- What model weights are
- Why ResNet50 was selected
- Limitations of ImageNet-based landmark recognition
- Difference between direct inference and transfer learning
