import numpy as np
import streamlit as st
import tensorflow as tf
from PIL import Image
from tensorflow.keras.applications.resnet50 import preprocess_input, decode_predictions

st.set_page_config(page_title="Landmark Image Classifier", page_icon="🏛️")

@st.cache_resource
def load_model():
    return tf.keras.applications.ResNet50(weights="imagenet")

model = load_model()

st.title("🏛️ Landmark Image Classification")
st.write(
    "Inference-only demonstration using a pre-trained ResNet50 "
    "model with ImageNet weights."
)

uploaded_file = st.file_uploader(
    "Upload a landmark or architecture image",
    type=["jpg", "jpeg", "png"]
)

if uploaded_file is not None:
    image = Image.open(uploaded_file).convert("RGB")

    st.image(image, caption="Input Image", use_container_width=True)

    resized = image.resize((224, 224))
    image_array = np.asarray(resized, dtype=np.float32)
    batch = np.expand_dims(image_array, axis=0)
    processed = preprocess_input(batch)

    with st.spinner("Running ResNet50 inference..."):
        predictions = model.predict(processed, verbose=0)

    results = decode_predictions(predictions, top=5)[0]

    st.subheader("Top-5 ImageNet Predictions")

    for rank, (_, label, probability) in enumerate(results, start=1):
        readable_label = label.replace("_", " ").title()
        st.write(f"**{rank}. {readable_label}** — {probability * 100:.2f}%")
        st.progress(float(probability))

    st.info(
        "Note: Standard ImageNet ResNet50 is not a dedicated landmark "
        "classifier. Its labels come from ImageNet's 1000 classes."
    )
